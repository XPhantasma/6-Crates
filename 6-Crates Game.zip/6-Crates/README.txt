6-Crates

A simple puzzle game for pyweek game jam 27

Description:
Its a basic puzzle game where you control a player in a 2d environment and interact with 6 different colored crates each with a unique characteristic when you interact with it. The object of the game is to push each unique crates to their respective color 

Controls

Arrow keys + Movement
R = Resets level

Arrow keys -> Spacebar = Interact
Spacebar -> R = returns to main menu

Esc = Quit(you can quit at anytime)
F12 = Screenshot

You can also see the controls on the "how2play" section in the main menu
